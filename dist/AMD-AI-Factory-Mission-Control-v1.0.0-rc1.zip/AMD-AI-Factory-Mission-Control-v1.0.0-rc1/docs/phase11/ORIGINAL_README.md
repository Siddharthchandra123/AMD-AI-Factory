# AMD AI Factory — Phase 10 Restart Drill Hotfix v1.0.1

Applies **only** to `scripts/test_phase10_restart.py`. The backend, scheduler, frontend, PostgreSQL, Redis, GPU settings, and saved benchmarks are unchanged.

## Reason

When `docker compose restart backend` interrupts a local HTTP request, `urllib.request.urlopen` may throw `http.client.RemoteDisconnected`. The original `poll` catches `urllib.error.URLError` but not that subclass of `http.client.HTTPException`/`ConnectionResetError`; a normal transient disconnect aborts the experiment and leaves synthetic jobs running. A subsequent attempt correctly refuses to run if the controller is not idle.

## Steps (Windows PowerShell from project root)

1. Extract this ZIP into the project root.
2. Inspect the failed test **without any new jobs or restarts**:

```powershell
python .\scripts\inspect_phase10_restart_v1_0_1.py --folder ".\results\hardening\restart_20261027T055258Z_554120"
```

3. Verify that the `queued_jobs` and `running_jobs` in `/api/cluster` are **both zero** and that the runtime is in `simulation` mode.
4. Check/apply the local test fix:

```powershell
python .\scripts\fix_phase10_restart_v1_0_1.py
python .\scripts\fix_phase10_restart_v1_0_1.py --apply
```

5. Once idle, run ONE restart drill:

```powershell
python .\scripts\test_phase10_restart.py --run --timeout 180
```

6. If it fails again, inspect its new `report.json` (`failed_phase`, `post_failure_cluster`, and `post_failure_recovery`) and backend logs:

```powershell
docker compose logs --tail 120 backend
```

## Limits

- The fix prevents a **false failure from a transient HTTP disconnect**. It does not claim the underlying restart recovery is correct until the live test passes.
- The test runs **only in local simulation mode**, creates synthetic jobs, and intentionally restarts the backend container.
- Do not attempt a new run while old jobs are active.
- The restart test is not a proof of at-most-once execution for real remote requests, multi-controller high availability, or all crash scenarios.
- Patching creates a timestamped `.bak_...` copy of the original script.
