# Phase 9 — Reliability and Recovery

**Status:** Offline API test kit prepared; requires live local Docker integration testing on Windows.

## Included
- Draining admission check under one-slot synthetic capacity.
- Queue backlog and pause/resume verification.
- Non-destructive original node setting preservation and recovery file.
- Distinct simulation evidence output.
- Standard-library-only Windows Python test runner.

## Still to implement or verify
- Running the drill on the user's Windows Docker backend.
- Backend restart behavior (separate controlled test, never performed automatically).
- Actual MI300X agent-disconnect and reconnect tests (GPU no longer provisioned).
- Real vLLM worker crash recovery, durable distributed state/HA and idempotent execution.
- Alerts/operational hardening and final release documentation.
