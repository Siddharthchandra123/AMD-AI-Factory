# Phase 8 — Scheduler Queue Policy Evaluation

Implemented offline evaluator and client-side Next.js visual comparison of actual `rank_queue()` policies. It is intentionally separate from archived MI300X real-hardware benchmark evidence and does not infer real GPU throughput.

## Acceptance checklist

- [x] Real project scheduler source imported at execution time
- [x] Nine available queue algorithms evaluated on identical per-trial traces
- [x] Four workload scenarios: bursts, multi-tenant skew, deadlines, continuous arrivals
- [x] Deterministic seeded runs and source/workload hashes
- [x] Per-job CSV, per-run CSV, per-policy aggregated CSV/JSON
- [x] Run isolation using timestamped directory
- [x] Frontend read-only result API and interactive scenario/policy/metric views
- [x] Self-contained Windows PowerShell onboarding and installer with backup
- [ ] User's Windows Docker integration and browser verification
- [ ] Separate live HTTP-level queue policy tests in simulation mode
- [ ] Multi-GPU placement and fairness validation on real hardware (future)

## Next after integration

Phase 9: fault injection and recovery with simulation/offline services, documenting expected behavior and preventing duplicate execution. Before submission, validate the dashboard, run matched trial batches, and confirm no unsupported claims are made about multi-GPU performance.
