# AMD AI Factory Mission Control — Phase 11 Release Kit

**Scope:** local Windows PowerShell + Docker Desktop release preparation. No MI300X, GPU, new cloud deployment, or Python libraries required. This is **not a full copy of the user's latest project**: it is an additive kit that builds a release from the **actual code on your laptop**.

## Installation (no core source modification)

From your existing project directory `C:\Users\Lenovo\Downloads\amd-ai-factory`:

```powershell
Expand-Archive -Path "$env:USERPROFILE\Downloads\amd-ai-factory-phase11-release-kit-v1.0.zip" -DestinationPath (Get-Location).Path -Force
```

This copies only new scripts and documentation under `scripts/`, `tests/`, and `docs/phase11/`.

## 1. Run non-disruptive end-to-end checks

```powershell
python .\scripts\phase11_regression.py --compose
```

Checks local source files, recorded Phase 9/10 drill evidence, security audit, runtime state, and the `/`, `/benchmarks`, `/scheduler-lab`, `/hardening` pages. It **does not submit jobs, restart containers, or change your configuration**. Evidence: `results/release/phase11_regression_latest.json`.

Offline-only mode when Docker services are stopped:

```powershell
python .\scripts\phase11_regression.py --offline
```

Some warnings are normal if optional archives or pages are not present; resolve failing checks before release.

## 2. Test the release tooling

```powershell
python -m unittest discover -s .\tests -p "test_phase11_release.py" -v
```

## 3. Inspect and build a GitHub-ready source release

```powershell
python .\scripts\phase11_release.py --dry-run
python .\scripts\phase11_release.py --version v1.0.0-rc1
```

Generated locally:

```text
dist/AMD-AI-Factory-Mission-Control-v1.0.0-rc1.zip
dist/AMD-AI-Factory-Mission-Control-v1.0.0-rc1.zip.sha256
```

Validate integrity:

```powershell
python .\scripts\phase11_verify_zip.py .\dist\AMD-AI-Factory-Mission-Control-v1.0.0-rc1.zip
```

The ZIP is built from **your local working project**, NOT from an outdated generated snapshot. You own the final version. It never pushes code or uploads it anywhere.

## Security defaults

- The release excludes `.env`, local credentials, private keys, tokens, certificates, Git metadata, IDE caches, local databases, Docker volumes, model weights, `results/`, `backups/`, and binary job archives.
- **Raw prompts, generated model responses, and detailed job logs are excluded** by excluding `results/` by default. Be careful: model prompts can also appear in docs or code; inspect before publication.
- The included curated `docs/phase11/evidence/` CSVs contain aggregate and timing-only figures reconstructed from user-provided test outputs. They are not a substitute for the raw independently reprocessed archive.
- An automated secret pattern scan blocks packaging when obvious embedded credentials are detected in included text. It is **not exhaustive**; manually review the release and `git diff` before publishing.
- The latest Phase 10 audit had 9/9 passing local configuration checks. This is not production authentication or a penetration test.

## What is complete and what remains

Real MI300X single-endpoint inference (4/8/16 jobs), v0.5 one-run optimization, v0.6 path profiling, simulated scheduling-policy experiments, simulated drain/resume 6/6, and simulated controller restart 6/6 have been demonstrated. Full Kubernetes/multi-node orchestration, multi-GPU placement validation, native high-resolution real vLLM metrics and production security are outside this v1.0 release candidate.

**Release quality gate:** run regression, review warnings, build ZIP, verify manifest, inspect archive names, optionally test Docker Compose from a fresh directory, only then tag/publish it.
